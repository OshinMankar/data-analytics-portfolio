// OP1: insertMany() — insert all 3 documents

db.products.insertMany([
{
  product_id: "E101",
  name: "Smartphone X",
  category: "Electronics",
  price: 45000,
  warranty_years: 2,
  specifications: {
    battery: "5000mAh",
    voltage: "220V"
  }
},

{
  product_id: "C201",
  name: "Men T-Shirt",
  category: "Clothing",
  price: 1200,
  size_available: ["S","M","L","XL"],
  material: "Cotton"
},

{
  product_id: "G301",
  name: "Organic Almond Milk",
  category: "Groceries",
  price: 250,
  expiry_date: "2024-12-30",
  nutrition: {
    calories: 60,
    protein: "2g"
  }
}
]);


// OP2: find Electronics with price > 20000

db.products.find({
  category: "Electronics",
  price: { $gt: 20000 }
});


// OP3: find groceries expiring before 2025

db.products.find({
  category: "Groceries",
  expiry_date: { $lt: "2025-01-01" }
});


// OP4: updateOne() add discount_percent

db.products.updateOne(
  { product_id: "E101" },
  { $set: { discount_percent: 10 } }
);


// OP5: create index on category

db.products.createIndex({ category: 1 });

